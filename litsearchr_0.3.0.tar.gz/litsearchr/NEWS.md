# litsearchr 0.1.0

Initial version of litsearchr. 


# litsearchr 0.2.0

Changes made in the new version of litsearchr:
 -- reduced package dependencies to reduce recursive dependencies
 -- eliminated dependence on rJava with an alternative keyword extraction algorithm
 -- made the search writing function more efficient
 -- moved import and deduplicate functions to wrapping synthesisr
 -- incorporated comments and ideas from the Evidence Synthesis Hackathon
