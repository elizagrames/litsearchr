fit_splines(
  importances = data.frame(rank = c(1:5), importance = c(20, 20, 30, 35, 90)),
  degrees = 2,
  knot_num = 1,
  knots = 2.99
)
