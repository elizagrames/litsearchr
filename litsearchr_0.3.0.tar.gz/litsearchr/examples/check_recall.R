check_recall(
  true_hits = c("Picoides arcticus"),
  retrieved = c("Picoides tridactylus",
                         "Seiurus aurocapilla")
)
