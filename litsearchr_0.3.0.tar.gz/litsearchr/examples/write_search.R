write_search(
  groupdata = list(
    c("black-backed woodpecker", "picoides arcticus"),
    c("post-fire forest", "time since fire")
  ),
  languages = "English",
  exactphrase = TRUE,
  stemming = TRUE,
  closure = "left",
  writesearch = FALSE,
  verbose = FALSE
)
