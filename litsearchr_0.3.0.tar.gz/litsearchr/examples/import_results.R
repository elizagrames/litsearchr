file_location <- system.file("extdata/scopus.ris", package="synthesisr")
naive_results <- import_results(file=file_location)
