write_title_search(
  c("Cross-scale occupancy dynamics of a postfire specialist
    in response to variation across a fire regime",
    "Variation in home-range size of Black-backed Woodpeckers")
)
